# Name: Trash Houses
# Purpose: Creates a separate shapefile for each town, which lists all of the houses & the day trash is collected

# Import system modules
import arcpy
import csv
import os

# Workspace and inputs
input_directory = r"Y:\Desktop\Python_midterm"
input_shp = "e911_Aquid.shp"
input_csv = "TrashStreets.csv"
patch_file = "trash_polygon.shp"

all_towns = True
town = ["MIDDLETOWN"]

spell_check = False

# Environmental settings
arcpy.env.workspace = input_directory
arcpy.env.overwriteOutput = True
keep_temp_files = False

# Create temporary and output folders
print "Adding folders..."

if not os.path.exists(os.path.join(input_directory, "_Scratch")):
    os.mkdir(os.path.join(input_directory, "_Scratch"))
if not os.path.exists(os.path.join(input_directory, "_Output")):
    os.mkdir(os.path.join(input_directory, "_Output"))

# Create list of towns
print "Adding towns..."
if all_towns == True:
    town = []
    with open(os.path.join(input_directory, input_csv)) as town_csv:
        header_line = town_csv.next()
        for row in csv.reader(town_csv):
            try:
                if row[0] not in town:
                    town.append(row[0])
            except:
                pass
    for i in town:
        print "\tAdded " + i
else:
    for i in town:
        print "\tAdded " + i

# Create separate csv files for each town

print "Splitting csv..."

for i in town:
    count = 1
    with open(os.path.join(input_directory, input_csv)) as houses:
        headerline = houses.next()
        for row in csv.reader(houses):
            if row[0] == i:
                if count == 1:
                    file = open(os.path.join(input_directory,"_Scratch", str(i) + ".csv"), "w")
                    file.write(headerline)
                    count = 0
                file.write(",".join(row))
                file.write("\n")
    file.close()
    print "\tCreated csv for " + i

# Patching shapefile for later use...
# https://desktop.arcgis.com/en/arcmap/10.3/tools/analysis-toolbox/identity.htm

print "Adding data from patch file to shapefile..."
arcpy.Identity_analysis(input_shp, patch_file, "_Scratch/input_identity.shp")
print "\tAdded data"
arcpy.DeleteField_management("_Scratch/input_identity.shp", ["FID_Trash_", "NAME"])
print "\tRemoved extra fields"

# Create separate shape file for each town -- select tool
# https://desktop.arcgis.com/en/arcmap/10.3/tools/analysis-toolbox/select.htm

print "Splitting shapefile..."


for i in town:
    selection_criteria = "ZN = '" + i + "' AND SiteType NOT IN ('A1','A2','A9','ET','U1','H1','G1','G2')"
    arcpy.Select_analysis("_Scratch/input_identity.shp", "_Output/" + i + ".shp", selection_criteria)
    print "\tCreated shapefile for " + i

# Check csv file for misspelled street names
# https://pro.arcgis.com/en/pro-app/arcpy/data-access/searchcursor-class.htm

print "Checking csv for spelling errors..."
for i in town:
    town_shp = "_Output/" + i + ".shp"
    town_csv = "_Scratch/" + i + ".csv"
    fields = ['ALIName','Alias1']
    StreetList = []
    WrongStreet = []
    with arcpy.da.SearchCursor(town_shp, fields) as cursor:
        for row in cursor:
            if row[0] not in StreetList:
                StreetList.append(row[0])
            if row[1] not in StreetList:
                StreetList.append(row[1])
    with open(town_csv) as streets:
        headerline = streets.next()
        for row in csv.reader(streets):
            if row[1] not in StreetList:
                WrongStreet.append(row[1])
    file.close()
    print "\tFound " + str(len(WrongStreet)) + " errors in " + i + ":\n\t\t" + str(WrongStreet)
    if spell_check == True:
        if len(WrongStreet) > 0:
            print "\tCorrect spellings:\n\t\t" + str(StreetList)

# Add new column to town shapefiles (GarbageDay) and populate field with data from csv files
# Add field: https://pro.arcgis.com/en/pro-app/tool-reference/data-management/add-field.htm
# Update cursor: https://pro.arcgis.com/en/pro-app/arcpy/data-access/updatecursor-class.htm

print "Joining csv and shapefiles..."

for i in town:
    print "\tAdding field to " + i + " shapefile..."
    town_shp = "_Output/" + i + ".shp"
    arcpy.AddField_management(town_shp, "GarbageDay", "TEXT", field_length=20)
    print "\tListing streets in " + i + "..."
    streetList = {}
    with open(os.path.join(input_directory, "_Scratch", str(i) + ".csv")) as garbageboy:
        headerline = garbageboy.next()
        for row in csv.reader(garbageboy):
            try:
                if row[1] not in streetList:
                    streetList[row[1]] = row[2]
            except:
                pass
    print "\tAdding garbage days to " + i + " shapefile..."
    for j in streetList:
        fields = ["ALIName", "Alias1", "GarbageDay", "TrashDay"]
        with arcpy.da.UpdateCursor(town_shp, fields) as cursor:
            # For each row, evaluate the ALIName value (index position
            # of 0) and Alias1 (index position of 1), and update GarbageDay (index position of 2)
            for row in cursor:
                if row[0] == j:
                    row[2] = streetList[j]
                elif row[1] == j:
                    row[2] = streetList[j]
                # Update the cursor with the updated list
                cursor.updateRow(row)
                # Replace any GarbageDay value of "Custom" with value from TrashDay
                if row[2] == "CUSTOM":
                    row[2] = row[3]
                cursor.updateRow(row)

print "Cleaning files..."
for i in town:
    town_shp = "_Output/" + i + ".shp"
    arcpy.DeleteField_management(town_shp, ["FID_e911_A", "TrashDay"])
    print "\tRemoved extra fields for " + i

# Join house shapefile and patch shapefile to account for "custom" street days
# https://desktop.arcgis.com/en/arcmap/10.3/tools/analysis-toolbox/identity.htm


# Delete temporary files

if keep_temp_files == False:
    print "Deleting temporary files..."
    arcpy.Delete_management(os.path.join(input_directory, "_Scratch"))
    print "\tFiles deleted"
